import SetConfig from './SetConfig'

SetConfig.install = function (Vue) {
  Vue.component(SetConfig.name, SetConfig)
}

export default SetConfig
