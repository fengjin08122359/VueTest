import AddAppChannel from './AddAppChannel'

AddAppChannel.install = function (Vue) {
  Vue.component(AddAppChannel.name, AddAppChannel)
}

export default AddAppChannel
