import AddWxChannel from './AddWxChannel'

AddWxChannel.install = function (Vue) {
  Vue.component(AddWxChannel.name, AddWxChannel)
}

export default AddWxChannel
