<template>
  <div class="pcPreview">
    {{ msg }}
  </div>
</template>

<script>
export default {
  name: 'PcPreview',
  data () {
    return {
      msg: 'PcPreview'
    }
  }
}
</script>
