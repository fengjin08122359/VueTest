import H5Preview from './H5Preview'

H5Preview.install = function (Vue) {
  Vue.component(H5Preview.name, H5Preview)
}

export default H5Preview
