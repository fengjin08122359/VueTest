import PcAppearance from './PcAppearance'

PcAppearance.install = function (Vue) {
  Vue.component(PcAppearance.name, PcAppearance)
}

export default PcAppearance
