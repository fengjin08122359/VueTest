<template>
  <div class="header">
    <img src="">
  </div>
</template>

<script>
export default {
  name: 'ncheader',
  data () {
    return {
    }
  }
}
</script>
